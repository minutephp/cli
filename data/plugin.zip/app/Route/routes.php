<?php

/** @var Router $router */
use Minute\Model\Permission;
use Minute\Routing\Router;

