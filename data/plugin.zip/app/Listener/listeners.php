<?php

/** @var Binding $binding */
use Minute\Event\Binding;

$binding->addMultiple([
    //static event listeners go here
    //['event' => 'EVENT', 'handler' => [Binding::class, 'fn'], 'priority' => 0]
]);